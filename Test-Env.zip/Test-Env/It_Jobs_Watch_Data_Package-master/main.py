from src.cmd_user_interface import CmdUserInterface

if __name__ == '__main__':
    CmdUserInterface()
